﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.Capture;
using Windows.Media.MediaProperties;
using Windows.Storage;
using Windows.Storage.Streams;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Microsoft.Maker.Devices.Gpio.PirSensor;
using Windows.Devices.Gpio;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking;
using FtpClientSample;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private MediaCapture mediaCapture;
        private StorageFile photoFile;
        private readonly string PHOTO_FILE_NAME = "photo.jpg";

        public MainPage()
        {
            this.InitializeComponent();
            PirSensor pir = new PirSensor(4, PirSensor.SensorType.ActiveHigh);
            pir.motionDetected += takePhoto_Click;

            //takePhoto_Click();
        }
        private async void takePhoto_Click(object sender, GpioPinValueChangedEventArgs args)
        {

            string serverUrl;
            Uri serverUri = null;
            try
            {
                mediaCapture = new MediaCapture();
                await mediaCapture.InitializeAsync();
                photoFile = await KnownFolders.SavedPictures.CreateFileAsync(
                    PHOTO_FILE_NAME, CreationCollisionOption.GenerateUniqueName);
                ImageEncodingProperties imageProperties = ImageEncodingProperties.CreateJpeg();
                var state = mediaCapture.CameraStreamState;
                await mediaCapture.CapturePhotoToStorageFileAsync(imageProperties, photoFile);
                WaitForFiveSeconds();
                //await SmallUpload1("ftp://192.168.1.146", photoFile);

                //IRandomAccessStream photoStream = await photoFile.OpenReadAsync();
                //BitmapImage bitmap = new BitmapImage();
                //bitmap.SetSource(photoStream);
                Uri uri = new Uri("ftp://192.168.1.146/", UriKind.Absolute);
                FtpClient client = new FtpClient();
                await client.ConnectAsync(
                    new HostName("192.168.1.146"),"21").ConfigureAwait(false);
                
                var bb = await photoFile.OpenReadAsync();
                byte[] data = ReadFully(bb.AsStream());
                if (data.Length > 5000)
                    await client.UploadAsync("sample.jpg", data);


            }
            catch (Exception ex)
            {
            }
        }
        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }

        public static async Task<bool> SmallUpload1(string ftpURIInfo, StorageFile targetFile)
        {

            string serverUrl;
            Uri serverUri = null;
            //StorageFolder localFolderArea;
            bool Successful = false;

            try
            {


                Uri.TryCreate(ftpURIInfo, UriKind.Absolute, out serverUri);
                serverUrl = serverUri.ToString();

                WebRequest request = WebRequest.Create(serverUrl + "/" + targetFile.Name);

                request.Proxy = WebRequest.DefaultWebProxy;

                //STOR is for ftp: // POST is for http:// web sites
                request.Method = "STOR";

                //byte[] buffer = Encoding.UTF8.GetBytes(UploadLine);




                using (Stream requestStream = await request.GetRequestStreamAsync())
                {
                    using (var stream = await targetFile.OpenStreamForReadAsync())
                    {
                        stream.CopyTo(requestStream);
                    }
                }

                Successful = true;

            }
            catch (Exception)
            {

                throw;
            }
            return Successful;

        }
        private async void WaitForFiveSeconds()
        {
            await System.Threading.Tasks.Task.Delay(TimeSpan.FromSeconds(5));
            // do something after 5 seconds!
        }
        //This is how you can set your resolution
        public async void SetResolution()
        {
            System.Collections.Generic.IReadOnlyList<IMediaEncodingProperties> res;
            res = this.mediaCapture.VideoDeviceController.GetAvailableMediaStreamProperties(MediaStreamType.VideoPreview);
            uint maxResolution = 0;
            int indexMaxResolution = 0;

            if (res.Count >= 1)
            {
                for (int i = 0; i < res.Count; i++)
                {
                    VideoEncodingProperties vp = (VideoEncodingProperties)res[i];

                    if (vp.Width > maxResolution)
                    {
                        indexMaxResolution = i;
                        maxResolution = vp.Width;
                    }
                }
                await this.mediaCapture.VideoDeviceController.SetMediaStreamPropertiesAsync(MediaStreamType.VideoPreview, res[indexMaxResolution]);
            }
        }
    }
}
