﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1
{
    public partial class MachineService
    {
        public int Id { get; set; }
        public int MachineId { get; set; }
        public Nullable<int> EmpId { get; set; }
        public Nullable<System.DateTime> ActualTime { get; set; }
        public Nullable<System.DateTime> ServiceTime { get; set; }
        public string MachineStatus { get; set; }
        public string UserStatus { get; set; }
        public string CallStatus { get; set; }
        public string CallSid { get; set; }
    }
}
