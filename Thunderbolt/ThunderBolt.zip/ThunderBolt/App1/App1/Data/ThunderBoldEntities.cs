﻿using Microsoft.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1
{
    public partial class ThunderBoltEntities : DbContext
    {
        System.Data.Common.DbConnection con;
        public ThunderBoltEntities()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            con.ConnectionString = "Data Source=s6t37il3h3.database.windows.net;Initial Catalog=ThunderBolt;Integrated Security=False;User ID=thunderbolt;Password=********;Connect Timeout=15;Encrypt=True;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;";
            optionsBuilder.UseSqlite(con);
        }

        public DbSet<MachineService> MachineServices { get; set; }
    }
}
