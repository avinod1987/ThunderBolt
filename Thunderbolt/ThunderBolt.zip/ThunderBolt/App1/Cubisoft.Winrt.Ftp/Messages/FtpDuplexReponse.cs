﻿namespace Cubisoft.Winrt.Ftp.Messages
{
    public class FtpDuplexReponse : FtpResponse
    {
        public string MessageBody { get; set; }
    }
}