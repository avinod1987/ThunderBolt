﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;
using ThunderBoltCallService.TextToSpeech;
using Twilio;

namespace ThunderBoltCallService
{
    class Program
    {
        static void Main(string[] args)
        {
            
           
        }
        public static void MakeCall()
        {
            string AccountSid = "AC5259df0b7c9ec2aa53bdd57bd9af1389";
            string AuthToken = "6da42ac45c85070b18aaf518b816cbac";
            var twilio = new TwilioRestClient(AccountSid, AuthToken);

            // Use the Twilio-provided site for the TwiML response.
            String Url = "http://twimlets.com/message";
            Url = Url + "?Message=Hello%20World!";

            // Build the parameters 
            var options = new CallOptions();
            options.To = "+918971888133";
            options.From = "+12542363434";
            options.Url = Url;
            options.Method = "GET";
            options.FallbackMethod = "POST";
            options.StatusCallbackMethod = "GET";
            options.Record = false;


            var call = twilio.InitiateOutboundCall(options);
            
            var status = twilio.GetCall(call.Sid);
        }
    }
}
