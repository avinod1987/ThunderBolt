﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThunderBoltCallService.TextToSpeech
{
    public class TextToSpeechService : ITextToSpeechService
    {
        public string XMLData(string message)
        {
            string response = "";
            try
            {
                var twiml = new Twilio.TwiML.TwilioResponse();
                twiml.Say(message);
                response = twiml.ToString();
            }
            catch (Exception)
            {
                throw;
            }
            return response;

        }
    }
}
